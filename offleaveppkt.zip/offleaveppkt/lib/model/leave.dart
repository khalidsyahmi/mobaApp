class Leave {

  final String date;
  final String reason;
  final int time;

  Leave({ this.date, this.reason, this.time });

}